package com.example.tanamao;

import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainCardapioActivity extends AppCompatActivity {

    private RecyclerView cafeRecycler, almocoRecycler, jantarRecycler;
    private EditText datePicker;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardapio); // <- nome correto do layout

        // Views
        datePicker = findViewById(R.id.date_picker);
        cafeRecycler = findViewById(R.id.recycler_cafe);
        almocoRecycler = findViewById(R.id.recycler_almoco);
        jantarRecycler = findViewById(R.id.recycler_jantar);

        cafeRecycler.setLayoutManager(new LinearLayoutManager(this));
        almocoRecycler.setLayoutManager(new LinearLayoutManager(this));
        jantarRecycler.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);

        String date = "02/06/2025";

        List<Meal> todas = dbHelper.getMealsForDate(date);

        List<Meal> cafe = new ArrayList<>();
        List<Meal> almoco = new ArrayList<>();
        List<Meal> jantar = new ArrayList<>();

        for (Meal meal : todas) {
            if (meal.getType().startsWith("cafe")) cafe.add(meal);
            else if (meal.getType().startsWith("almoco")) almoco.add(meal);
            else if (meal.getType().startsWith("jantar")) jantar.add(meal);
        }

        cafeRecycler.setAdapter(new MealAdapter(cafe, null));
        almocoRecycler.setAdapter(new MealAdapter(almoco, null));
        jantarRecycler.setAdapter(new MealAdapter(jantar, null));
    }
}
