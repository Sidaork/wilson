package com.example.tanamao;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MenuActivity extends AppCompatActivity {

    private EditText datePicker;
    private RecyclerView recyclerView;
    private MealAdapter adapter;
    private DatabaseHelper dbHelper;
    private String username;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // 1) findViewById
        datePicker    = findViewById(R.id.date_picker);
        recyclerView  = findViewById(R.id.menu_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        username = getIntent().getStringExtra("username");
        if (username == null) username = "Usuário";

        dbHelper = new DatabaseHelper(this);
        calendar = Calendar.getInstance();

        // 2) Mostrar data atual no campo
        String today = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        datePicker.setText(today);

        // 3) Gerar ou carregar o cardápio de hoje
        loadMenuForDate(today);

        // 4) DatePickerDialog ao clicar no EditText
        datePicker.setOnClickListener(v -> {
            int year  = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day   = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dpd = new DatePickerDialog(
                    MenuActivity.this,
                    (view, selYear, selMonth, selDay) -> {
                        calendar.set(selYear, selMonth, selDay);
                        String chosenDate = String.format(Locale.getDefault(),
                                "%02d/%02d/%04d", selDay, selMonth + 1, selYear);
                        datePicker.setText(chosenDate);
                        loadMenuForDate(chosenDate);
                    },
                    year, month, day
            );
            dpd.show();
        });

        // 5) Botões do rodapé
        findViewById(R.id.home_button).setOnClickListener(v -> {
            Intent i = new Intent(MenuActivity.this, HomeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
        findViewById(R.id.menu_button).setOnClickListener(v -> {
            // Já estamos no Menu, nada a fazer
        });
        findViewById(R.id.recharge_menu_button).setOnClickListener(v -> {
            Intent i = new Intent(MenuActivity.this, RechargeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
        findViewById(R.id.profile_button).setOnClickListener(v -> {
            Intent i = new Intent(MenuActivity.this, ProfileActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
    }

    /**
     * Carrega (ou gera) o cardápio para a data informada,
     * coloca no RecyclerView.
     */
    private void loadMenuForDate(String date) {
        // 1) Gera cardápio se não existir
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        dbHelper.generateMenuForDate(db, date);

        // 2) Busca do banco e passa ao adapter
        List<Meal> meals = dbHelper.getMealsForDate(date); // <- chamada corrigida
        adapter = new MealAdapter(meals, meal -> {
            // Clique num card do cardápio: exibe detalhes
            Intent intent = new Intent(MenuActivity.this, MealDetailActivity.class);
            intent.putExtra("meal_id", meal.getId());
            intent.putExtra("username", username);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        if (meals.isEmpty()) {
            Toast.makeText(this, "Ainda não há cardápio para " + date, Toast.LENGTH_SHORT).show();
        }
    }
}
