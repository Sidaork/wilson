package com.example.tanamao;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MealViewHolder> {

    private Context context;
    private List<Meal> mealList;
    private String username;

    public MenuAdapter(Context context, List<Meal> mealList, String username) {
        this.context = context;
        this.mealList = mealList;
        this.username = username;
    }

    @NonNull
    @Override
    public MealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cardapio, parent, false);
        return new MealViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MealViewHolder holder, int position) {
        Meal meal = mealList.get(position);

        holder.nameText.setText(meal.getName());
        holder.priceText.setText(String.format("R$ %.2f", meal.getPrice()));

        // Carrega imagem pelo nome (campo imageName no banco)
        int imageRes = context.getResources()
                .getIdentifier(meal.getImageName(), "drawable", context.getPackageName());
        if (imageRes != 0) {
            holder.imageMeal.setImageResource(imageRes);
        } else {
            holder.imageMeal.setImageResource(R.drawable.ic_launcher_foreground);
        }

        // Botão “Adicionar à Sacola”
        holder.addToBagButton.setOnClickListener(v -> {
            Toast.makeText(context, meal.getName() + " adicionado à sacola", Toast.LENGTH_SHORT).show();
            // Aqui você pode salvar no banco ou SharedPreferences
        });

        // Clique no card para abrir detalhes
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, MealDetailActivity.class);
            intent.putExtra("meal_id", meal.getId());
            intent.putExtra("username", username);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return mealList.size();
    }

    public static class MealViewHolder extends RecyclerView.ViewHolder {
        ImageView imageMeal;
        TextView nameText, priceText;
        Button addToBagButton;

        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            imageMeal = itemView.findViewById(R.id.image_meal);
            nameText = itemView.findViewById(R.id.text_meal_name);
            priceText = itemView.findViewById(R.id.text_meal_price);
            addToBagButton = itemView.findViewById(R.id.button_add_to_bag);
        }
    }
}
