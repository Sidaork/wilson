package com.example.tanamao;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    private final Context context;
    private final List<Meal> meals;

    public MenuAdapter(Context context, List<Meal> meals) {
        this.context = context;
        this.meals = meals;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.content_meal, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        Meal meal = meals.get(position);
        holder.name.setText(meal.getName());
        holder.description.setText(meal.getDescription());
        holder.price.setText(String.format("R$ %.2f", meal.getPrice()));
    }

    @Override
    public int getItemCount() {
        return meals.size();
    }

    static class MenuViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, price;

        MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.meal_name);
            description = itemView.findViewById(R.id.meal_description);
            price = itemView.findViewById(R.id.meal_price);
        }
    }
}
