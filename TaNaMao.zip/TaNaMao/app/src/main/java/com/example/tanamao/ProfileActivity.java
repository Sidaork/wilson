package com.example.tanamao;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private TextView balanceText, totalSpentText, totalRechargedText, usernameText;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        balanceText = findViewById(R.id.balance_text);
        totalSpentText = findViewById(R.id.total_spent);
        totalRechargedText = findViewById(R.id.total_recharged);
        usernameText = findViewById(R.id.username_text);

        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "Erro: usuário não identificado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        usernameText.setText("Bem-vindo, " + username);
        updateProfileInfo();
        setupFooterButtons();
        setupTopButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateProfileInfo();
    }

    private void updateProfileInfo() {
        if (!dbHelper.usuarioExiste(username)) {
            dbHelper.criarUsuario(username);
        }

        double saldo = dbHelper.getSaldoUsuario(username);
        double totalGasto = dbHelper.getTotalGastoUsuario(username);
        double totalRecarga = dbHelper.getTotalRecargaUsuario(username);

        balanceText.setText(String.format("Saldo: R$ %.2f", saldo));
        totalSpentText.setText(String.format("Total Gasto: R$ %.2f", totalGasto));
        totalRechargedText.setText(String.format("Total Recarregado: R$ %.2f", totalRecarga));
    }

    private void setupTopButtons() {
        findViewById(R.id.logout_button).setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            prefs.edit().remove("remember_login").remove("saved_username").apply();

            Intent i = new Intent(ProfileActivity.this, LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });

        findViewById(R.id.change_password_button).setOnClickListener(v -> {
            Toast.makeText(this, "Funcionalidade de troca de senha em breve.", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.help_button).setOnClickListener(v -> {
            Toast.makeText(this, "Para ajuda, fale com a cantina ou envie e-mail para suporte@tanamao.com", Toast.LENGTH_LONG).show();
        });
    }

    private void setupFooterButtons() {
        findViewById(R.id.home_button).setOnClickListener(v -> {
            Intent i = new Intent(ProfileActivity.this, HomeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.menu_button).setOnClickListener(v -> {
            Intent i = new Intent(ProfileActivity.this, MenuActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.recharge_menu_button).setOnClickListener(v -> {
            Intent i = new Intent(ProfileActivity.this, RechargeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.profile_button).setOnClickListener(v -> {
            Toast.makeText(this, "Você já está no Perfil", Toast.LENGTH_SHORT).show();
        });
    }
}
