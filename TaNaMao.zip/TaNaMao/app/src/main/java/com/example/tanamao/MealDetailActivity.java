package com.example.tanamao;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MealDetailActivity extends AppCompatActivity {

    private ImageView detailImage;
    private TextView detailName, detailDescription, detailPrice;
    private RatingBar detailRatingBar;
    private LinearLayout commentsContainer;
    private com.google.android.material.button.MaterialButton buttonAddComment, buttonAddToCart;

    private DatabaseHelper dbHelper;
    private Meal currentMeal;
    private String username;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_detail);

        detailImage = findViewById(R.id.detail_image);
        detailName = findViewById(R.id.detail_name);
        detailDescription = findViewById(R.id.detail_description);
        detailPrice = findViewById(R.id.detail_price);
        detailRatingBar = findViewById(R.id.detail_ratingbar);
        commentsContainer = findViewById(R.id.comments_container);
        buttonAddComment = findViewById(R.id.button_add_comment);
        buttonAddToCart = findViewById(R.id.button_add_to_cart);

        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");
        int mealId = getIntent().getIntExtra("meal_id", -1);

        currentMeal = dbHelper.getMealById(mealId);
        if (currentMeal == null) {
            Toast.makeText(this, "Refeição não encontrada", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        detailName.setText(currentMeal.getName() != null ? currentMeal.getName() : "Refeição sem nome");
        detailDescription.setText(currentMeal.getDescription() != null ? currentMeal.getDescription() : "Sem descrição");
        detailPrice.setText(String.format("R$ %.2f", currentMeal.getPrice()));
        detailRatingBar.setNumStars(10);
        detailRatingBar.setMax(10);
        detailRatingBar.setStepSize(1.0f);
        detailRatingBar.setRating((float) currentMeal.getRating());

        String imageName = currentMeal.getImageName() != null ? currentMeal.getImageName().replace(".jpg", "") : "default_image";
        int imageRes = getResources().getIdentifier(imageName, "drawable", getPackageName());
        if (imageRes != 0) {
            detailImage.setImageResource(imageRes);
        } else {
            detailImage.setImageResource(R.drawable.ic_launcher_foreground);
        }

        loadCommentsForMeal(mealId);
        buttonAddToCart.setEnabled(isToday(currentMeal.getDate()));

        buttonAddComment.setOnClickListener(v -> showAddCommentDialog());

        buttonAddToCart.setOnClickListener(v -> {
            if (isToday(currentMeal.getDate())) {
                dbHelper.addToCart(username, currentMeal.getId());
                Toast.makeText(this, currentMeal.getName() + " adicionado à sacola", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Só é possível adicionar refeições do dia atual", Toast.LENGTH_SHORT).show();
            }
        });

        // Correção aqui:
        detailRatingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            if (fromUser) {
                dbHelper.updateMealRating(mealId, rating);
                Toast.makeText(this, "Avaliação atualizada: " + rating, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadCommentsForMeal(int mealId) {
        commentsContainer.removeAllViews();
        List<Comment> comments = dbHelper.getCommentsForMeal(mealId);
        for (Comment comment : comments) {
            TextView commentView = new TextView(this);
            commentView.setText(comment.getUsername() + ": " + comment.getText());
            commentView.setTextColor(getResources().getColor(android.R.color.black));
            commentsContainer.addView(commentView);
        }
    }

    private void showAddCommentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adicionar Comentário");

        final EditText input = new EditText(this);
        input.setHint("Seu comentário");
        builder.setView(input);

        builder.setPositiveButton("Enviar", (dialog, which) -> {
            String newComment = input.getText().toString().trim();
            if (!newComment.isEmpty()) {
                dbHelper.addComment(currentMeal.getId(), username, newComment);
                loadCommentsForMeal(currentMeal.getId());
            }
        });
        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private boolean isToday(String mealDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String today = sdf.format(new Date());
        return today.equals(mealDate);
    }
}
