package com.example.tanamao;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.graphics.Color;


public class MealDetailActivity extends AppCompatActivity {

    private TextView detailName, detailDescription, detailPrice;
    private RatingBar detailRatingBar;
    private LinearLayout commentsContainer;
    private Button buttonAddComment;

    private DatabaseHelper dbHelper;
    private Meal currentMeal;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_detail);


        detailRatingBar = findViewById(R.id.detail_ratingbar);
        LayerDrawable stars = (LayerDrawable) detailRatingBar.getProgressDrawable();

        stars.getDrawable(2).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP); // filled stars
        stars.getDrawable(1).setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP); // half filled
        stars.getDrawable(0).setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP); // empty

        // Referências da interface
        detailName = findViewById(R.id.detail_name);
        detailDescription = findViewById(R.id.detail_description);
        detailPrice = findViewById(R.id.detail_price);
        detailRatingBar = findViewById(R.id.detail_ratingbar);
        commentsContainer = findViewById(R.id.comments_container);
        buttonAddComment = findViewById(R.id.button_add_comment);

        // Carregamento de dados
        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");
        int mealId = getIntent().getIntExtra("meal_id", -1);

        currentMeal = dbHelper.getMealById(mealId);
        if (currentMeal == null) {
            Toast.makeText(this, "Refeição não encontrada", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Preenche os dados
        detailName.setText(currentMeal.getName());
        detailDescription.setText(currentMeal.getDescription());
        detailPrice.setText(String.format("R$ %.2f", currentMeal.getPrice()));
        detailRatingBar.setRating((float) currentMeal.getRating());

        // Comentários
        loadCommentsForMeal(mealId);

        // Avaliação com estrelas
        detailRatingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            if (fromUser) {
                dbHelper.updateMealRating(mealId, rating);
                Toast.makeText(this, "Avaliação atualizada: " + rating, Toast.LENGTH_SHORT).show();
            }
        });

        // Botão para comentar
        buttonAddComment.setOnClickListener(v -> showAddCommentDialog());
    }

    private void loadCommentsForMeal(int mealId) {
        commentsContainer.removeAllViews();
        List<Comment> comments = dbHelper.getCommentsForMeal(mealId);
        for (Comment comment : comments) {
            TextView commentView = new TextView(this);
            commentView.setText(comment.getUsername() + ": " + comment.getText());
            commentView.setTextSize(14);
            commentView.setTextColor(getResources().getColor(android.R.color.black));
            commentView.setPadding(0, 4, 0, 4);
            commentsContainer.addView(commentView);
        }
    }

    private void showAddCommentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adicionar Comentário");

        final EditText input = new EditText(this);
        input.setHint("Seu comentário");
        builder.setView(input);

        builder.setPositiveButton("Enviar", (dialog, which) -> {
            String newComment = input.getText().toString().trim();
            if (!newComment.isEmpty()) {
                dbHelper.addComment(currentMeal.getId(), username, newComment);
                loadCommentsForMeal(currentMeal.getId());
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
