package com.example.tanamao;

public class Comment {
    private int id;
    private int mealId;
    private String username;
    private String text;

    public Comment(int id, int mealId, String username, String text) {
        this.id = id;
        this.mealId = mealId;
        this.username = username;
        this.text = text;
    }

    public int getId() { return id; }
    public int getMealId() { return mealId; }
    public String getUsername() { return username; }
    public String getText() { return text; }
}