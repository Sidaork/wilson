package com.example.tanamao;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {

    private LinearLayout mealsContainer;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mealsContainer = findViewById(R.id.meals_container);
        TextView welcomeText = findViewById(R.id.welcome_text);
        TextView dateText = findViewById(R.id.date_text);

        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "Usuário não informado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        welcomeText.setText("Bem-vindo, " + username);

        String today = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        dateText.setText("Data: " + today);

        loadMealsForToday();
        setupFooterButtons();
    }

    private void loadMealsForToday() {
        String today = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        List<Meal> meals = dbHelper.getMealsForDate(today);

        mealsContainer.removeAllViews();
        if (meals.isEmpty()) {
            TextView noMeals = new TextView(this);
            noMeals.setText("Cardápio ainda não disponível para este dia.");
            noMeals.setTextSize(16);
            noMeals.setTextColor(getResources().getColor(android.R.color.black));
            mealsContainer.addView(noMeals);
        } else {
            Map<String, List<Meal>> grouped = new LinkedHashMap<>();
            for (Meal meal : meals) {
                String key = meal.getType().toUpperCase() + " – " + meal.getSubtype().toUpperCase();
                if (!grouped.containsKey(key)) {
                    grouped.put(key, new java.util.ArrayList<>());
                }
                grouped.get(key).add(meal);
            }

            for (String groupTitle : grouped.keySet()) {
                TextView groupHeader = new TextView(this);
                groupHeader.setText(groupTitle);
                groupHeader.setTextSize(18);
                groupHeader.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                groupHeader.setPadding(0, 16, 0, 8);
                mealsContainer.addView(groupHeader);

                for (Meal meal : grouped.get(groupTitle)) {
                    TextView mealView = new TextView(this);
                    mealView.setText(meal.getName() + " - R$ " + String.format("%.2f", meal.getPrice()));
                    mealView.setTextSize(16);
                    mealView.setTextColor(getResources().getColor(android.R.color.black));
                    mealView.setPadding(16, 4, 0, 4);
                    mealView.setOnClickListener(v -> {
                        Intent intent = new Intent(HomeActivity.this, MealDetailActivity.class);
                        intent.putExtra("username", username);
                        intent.putExtra("meal_id", meal.getId());
                        startActivity(intent);
                    });
                    mealsContainer.addView(mealView);
                }
            }
        }
    }

    private void setupFooterButtons() {
        findViewById(R.id.home_button).setOnClickListener(v -> {
            Toast.makeText(this, "Você já está na tela inicial", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.menu_button).setOnClickListener(v -> {
            Intent i = new Intent(HomeActivity.this, MenuActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.recharge_menu_button).setOnClickListener(v -> {
            Intent i = new Intent(HomeActivity.this, RechargeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.profile_button).setOnClickListener(v -> {
            Intent i = new Intent(HomeActivity.this, ProfileActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
    }
}
