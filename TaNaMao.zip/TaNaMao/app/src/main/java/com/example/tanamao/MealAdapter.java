package com.example.tanamao;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MealAdapter extends RecyclerView.Adapter<MealAdapter.MealViewHolder> {

    private final List<Meal> meals;
    private final OnMealClickListener listener;

    public interface OnMealClickListener {
        void onMealClick(Meal meal);
    }

    public MealAdapter(List<Meal> meals, OnMealClickListener listener) {
        this.meals = meals;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.content_meal, parent, false);
        return new MealViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MealViewHolder holder, int position) {
        Meal meal = meals.get(position);

        // Configurar nome, descrição e preço
        holder.name.setText(meal.getName() != null ? meal.getName() : "Refeição sem nome");
        holder.description.setText(meal.getDescription() != null ? meal.getDescription() : "Sem descrição");
        holder.price.setText(String.format("R$ %.2f", meal.getPrice()));

        // Carregar imagem
        String imageName = meal.getImageName() != null ? meal.getImageName().replace(".jpg", "") : "default_image";
        int imageRes = holder.itemView.getContext().getResources()
                .getIdentifier(imageName, "drawable", holder.itemView.getContext().getPackageName());
        if (imageRes != 0) {
            holder.image.setImageResource(imageRes);
        } else {
            holder.image.setImageResource(R.drawable.ic_launcher_foreground);
        }

        // Botão "Adicionar à Sacola"
        holder.buttonAddToBag.setOnClickListener(v -> {
            Toast.makeText(
                    holder.itemView.getContext(),
                    (meal.getName() != null ? meal.getName() : "Refeição") + " adicionado à sacola",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Clique no card abre tela de detalhes
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onMealClick(meal);
            }
        });
    }

    @Override
    public int getItemCount() {
        return meals != null ? meals.size() : 0;
    }

    static class MealViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name, description, price;
        Button buttonAddToBag;

        MealViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.meal_image);
            name = itemView.findViewById(R.id.meal_name);
            description = itemView.findViewById(R.id.meal_description);
            price = itemView.findViewById(R.id.meal_price);
            buttonAddToBag = itemView.findViewById(R.id.button_add_to_bag);
        }
    }
}