package com.example.tanamao;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MealAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    private final List<Object> displayList = new ArrayList<>();
    private final OnMealClickListener listener;

    public interface OnMealClickListener {
        void onMealClick(Meal meal);
    }

    public MealAdapter(List<Meal> meals, OnMealClickListener listener) {
        this.listener = listener;
        buildDisplayList(meals);
    }

    private void buildDisplayList(List<Meal> meals) {
        Map<String, List<Meal>> grouped = new LinkedHashMap<>();
        for (Meal meal : meals) {
            String key = meal.getType().toUpperCase() + " – " + meal.getSubtype().toUpperCase();
            if (!grouped.containsKey(key)) grouped.put(key, new ArrayList<>());
            grouped.get(key).add(meal);
        }
        for (Map.Entry<String, List<Meal>> entry : grouped.entrySet()) {
            displayList.add(entry.getKey());
            displayList.addAll(entry.getValue());
        }
    }

    @Override
    public int getItemViewType(int position) {
        return displayList.get(position) instanceof String ? TYPE_HEADER : TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_meal_header, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_meal, parent, false);
            return new MealViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == TYPE_HEADER) {
            String title = (String) displayList.get(position);
            ((HeaderViewHolder) holder).header.setText(title);
        } else {
            Meal meal = (Meal) displayList.get(position);
            MealViewHolder vh = (MealViewHolder) holder;
            vh.name.setText(meal.getName());
            vh.description.setText(meal.getDescription());
            vh.price.setText(String.format("R$ %.2f", meal.getPrice()));
            vh.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onMealClick(meal);
            });
        }
    }

    @Override
    public int getItemCount() {
        return displayList.size();
    }

    static class MealViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, price;
        MealViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.meal_name);
            description = itemView.findViewById(R.id.meal_description);
            price = itemView.findViewById(R.id.meal_price);
        }
    }

    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView header;
        HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            header = itemView.findViewById(R.id.header_text);
        }
    }
}
