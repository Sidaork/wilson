package com.example.tanamao;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RechargeActivity extends AppCompatActivity {

    private TextView balanceText;
    private EditText codeInput;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recharge);

        balanceText = findViewById(R.id.balance_text);
        codeInput = findViewById(R.id.code_input);
        dbHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        if (username == null) username = "Usuário";

        double saldo = dbHelper.getSaldoUsuario(username);
        balanceText.setText("Saldo: R$ " + String.format("%.2f", saldo));

        findViewById(R.id.recharge_button).setOnClickListener(v -> {
            String code = codeInput.getText().toString().trim();
            if (TextUtils.isEmpty(code)) {
                Toast.makeText(this, "Digite um código", Toast.LENGTH_SHORT).show();
                return;
            }

            if (code.startsWith("RECARGA ")) {
                String[] parts = code.split(" ");
                if (parts.length == 2) {
                    try {
                        double valor = Double.parseDouble(parts[1]);
                        double saldoAtual = dbHelper.getSaldoUsuario(username);
                        double novoSaldo = saldoAtual + valor;

                        dbHelper.atualizarSaldo(username, novoSaldo);
                        dbHelper.atualizarTotalRecarga(username, valor);

                        Toast.makeText(this, "Recarregado: R$ " + String.format("%.2f", valor), Toast.LENGTH_SHORT).show();
                        codeInput.setText("");
                        balanceText.setText("Saldo: R$ " + String.format("%.2f", novoSaldo));

                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Formato correto: RECARGA 10", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Código inválido", Toast.LENGTH_SHORT).show();
            }
        });

        setupFooterButtons();
    }

    private void setupFooterButtons() {
        findViewById(R.id.home_button).setOnClickListener(v -> {
            Intent i = new Intent(this, HomeActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.menu_button).setOnClickListener(v -> {
            Intent i = new Intent(this, MenuActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        findViewById(R.id.recharge_menu_button).setOnClickListener(v -> {
            // já está na tela de recarga
        });

        findViewById(R.id.profile_button).setOnClickListener(v -> {
            Intent i = new Intent(this, ProfileActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
    }
}
