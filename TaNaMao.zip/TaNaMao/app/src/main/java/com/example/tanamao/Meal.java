package com.example.tanamao;

public class Meal {
    private int id;
    private String date;
    private String type;
    private String name;
    private String description;
    private double price;
    private double rating;
    private String imageName;

    public Meal(int id, String date, String type, String name, String description, double price, double rating, String imageName) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.name = name;
        this.description = description;
        this.price = price;
        this.rating = rating;
        this.imageName = imageName;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public String getType() { return type; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public double getRating() { return rating; }
    public String getImageName() { return imageName; }
}