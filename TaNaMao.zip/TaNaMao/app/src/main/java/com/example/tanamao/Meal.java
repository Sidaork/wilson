package com.example.tanamao;

public class Meal {
    private int id;
    private String date;
    private String type;      // café, almoço, jantar
    private String subtype;   // normal, vegetariano, intolerante
    private String itemType;  // comida, bebida, complemento, sobremesa
    private String name;
    private String description;
    private double price;
    private double rating;

    public Meal(int id, String date, String type, String subtype, String itemType,
                String name, String description, double price, double rating) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.subtype = subtype;
        this.itemType = itemType;
        this.name = name;
        this.description = description;
        this.price = price;
        this.rating = rating;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public String getType() { return type; }
    public String getSubtype() { return subtype; }
    public String getItemType() { return itemType; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public double getRating() { return rating; }
}
