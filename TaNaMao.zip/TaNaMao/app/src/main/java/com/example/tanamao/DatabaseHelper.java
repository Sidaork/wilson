package com.example.tanamao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tanamao.db";
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "username TEXT PRIMARY KEY, " +
                "password TEXT, " +
                "saldo REAL, " +
                "total_gasto REAL, " +
                "total_recarga REAL)");

        db.execSQL("CREATE TABLE meals (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "type TEXT, " +
                "subtype TEXT, " +
                "itemType TEXT, " +
                "name TEXT, " +
                "description TEXT, " +
                "price REAL, " +
                "rating REAL)");

        db.execSQL("CREATE TABLE comments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "meal_id INTEGER, " +
                "username TEXT, " +
                "comment TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS meals");
        db.execSQL("DROP TABLE IF EXISTS comments");
        onCreate(db);
    }

    public boolean usuarioExiste(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"username"}, "username = ?", new String[]{username}, null, null, null);
        boolean existe = cursor != null && cursor.moveToFirst();
        if (cursor != null) cursor.close();
        return existe;
    }

    public void criarUsuario(String username) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", "");
        values.put("saldo", 0.0);
        values.put("total_gasto", 0.0);
        values.put("total_recarga", 0.0);
        db.insert("users", null, values);
    }

    public double getSaldoUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"saldo"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double saldo = cursor.getDouble(cursor.getColumnIndexOrThrow("saldo"));
            cursor.close();
            return saldo;
        }
        return 0.0;
    }

    public double getTotalGastoUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"total_gasto"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double total = cursor.getDouble(cursor.getColumnIndexOrThrow("total_gasto"));
            cursor.close();
            return total;
        }
        return 0.0;
    }

    public double getTotalRecargaUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"total_recarga"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double total = cursor.getDouble(cursor.getColumnIndexOrThrow("total_recarga"));
            cursor.close();
            return total;
        }
        return 0.0;
    }

    public void atualizarSaldo(String username, double novoSaldo) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("saldo", novoSaldo);
        db.update("users", values, "username = ?", new String[]{username});
    }

    public void atualizarTotalRecarga(String username, double valor) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.query("users", new String[]{"total_recarga"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double atual = cursor.getDouble(cursor.getColumnIndexOrThrow("total_recarga"));
            cursor.close();

            ContentValues values = new ContentValues();
            values.put("total_recarga", atual + valor);
            db.update("users", values, "username = ?", new String[]{username});
        } else {
            criarUsuario(username);
            atualizarTotalRecarga(username, valor);
        }
    }

    public List<Meal> getMealsForDate(String date) {
        List<Meal> meals = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM meals WHERE date = ?", new String[]{date});

        if (cursor.moveToFirst()) {
            do {
                Meal meal = new Meal(
                        cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("date")),
                        cursor.getString(cursor.getColumnIndexOrThrow("type")),
                        cursor.getString(cursor.getColumnIndexOrThrow("subtype")),
                        cursor.getString(cursor.getColumnIndexOrThrow("itemType")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("description")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("rating"))
                );
                meals.add(meal);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return meals;
    }

    public Meal getMealById(int mealId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM meals WHERE id = ?", new String[]{String.valueOf(mealId)});
        if (cursor.moveToFirst()) {
            Meal meal = new Meal(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    cursor.getString(cursor.getColumnIndexOrThrow("type")),
                    cursor.getString(cursor.getColumnIndexOrThrow("subtype")),
                    cursor.getString(cursor.getColumnIndexOrThrow("itemType")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                    cursor.getDouble(cursor.getColumnIndexOrThrow("rating"))
            );
            cursor.close();
            return meal;
        }
        cursor.close();
        return null;
    }

    public void updateMealRating(int mealId, float rating) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rating", rating);
        db.update("meals", values, "id = ?", new String[]{String.valueOf(mealId)});
    }

    public void addMeal(String date, String type, String subtype, String itemType,
                        String name, String description, double price, double rating) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("type", type);
        values.put("subtype", subtype);
        values.put("itemType", itemType);
        values.put("name", name);
        values.put("description", description);
        values.put("price", price);
        values.put("rating", rating);
        db.insert("meals", null, values);
    }

    // Método completo e final de geração do cardápio diário
    public void generateMenuForDate(SQLiteDatabase db, String date) {
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM meals WHERE date = ?", new String[]{date});
        if (cursor.moveToFirst()) {
            int count = cursor.getInt(0);
            cursor.close();
            if (count > 0) return;
        } else {
            cursor.close();
        }

        String[] types = {"café", "almoço", "jantar"};
        String[] subtypes = {"normal", "vegetariano", "intolerante"};
        String[] itemTypes = {"comida", "bebida", "complemento", "sobremesa"};
        int[] limits = {15, 10, 8, 5};
        Random rand = new Random();

        Map<String, Map<String, List<String>>> cardapio = new HashMap<>();

        cardapio.put("normal", new HashMap<>());
        cardapio.put("vegetariano", new HashMap<>());
        cardapio.put("intolerante", new HashMap<>());

        // Comidas
// ----------------------------------------------
        cardapio.get("normal").put("comida", List.of(
                "Bife acebolado", "Frango grelhado", "Estrogonofe de carne", "Arroz com feijão", "Lasanha",
                "Escondidinho de carne", "Omelete", "Macarrão com molho", "Carne moída", "Arroz à grega",
                "Sopa de carne", "Torta de frango", "Panqueca de carne", "Pizza de calabresa", "Hambúrguer artesanal",
                "Arroz carreteiro", "Feijoada", "Costela com mandioca", "Frango ao curry", "Risoto de frango",
                "Carne de panela", "Lasanha bolonhesa", "Almondegas", "Bife à milanesa", "Strogonoff tradicional",
                "Arroz branco", "Macarronada com carne", "Esfiha de carne", "Quibe frito", "Panqueca recheada",
                "Frango com quiabo", "Arroz com cenoura", "Coxa de frango", "Linguiça acebolada", "Moela refogada",
                "Dobradinha", "Bife de fígado", "Torta salgada", "Misto quente", "Carne com batata",
                "Arroz com milho", "Pernil", "Bife rolê", "Churrasco", "Arroz de forno", "Galinhada",
                "Macarrão alho e óleo", "Estrogonofe simples", "Pizza simples", "Frango xadrez",
                "Arroz de açafrão", "Cuscuz com carne", "Tapioca com carne", "Panqueca de presunto", "Feijão preto",
                "Frango empanado", "Pão com carne", "Escondidinho simples", "Carne desfiada", "Torrada com presunto"
        ));

        cardapio.get("vegetariano").put("comida", List.of(
                "Tofu grelhado", "Lasanha de berinjela", "Estrogonofe de soja", "Arroz com lentilha", "Salada de grãos",
                "Panqueca de espinafre", "Moqueca de banana-da-terra", "Pizza vegetariana", "Hambúrguer de lentilha", "Macarrão integral com legumes",
                "Quibe de abóbora", "Cuscuz com legumes", "Torta de legumes", "Risoto de cogumelos", "Panqueca de cenoura",
                "Sopa de legumes", "Wrap vegetariano", "Ovo cozido", "Omelete com espinafre", "Arroz com cenoura",
                "Grão-de-bico refogado", "Tapioca com tofu", "Berinjela assada", "Minestrone", "Crepioca",
                "Torta de espinafre", "Tapioca salgada", "Salada quente", "Berinjela recheada", "Escondidinho vegetariano",
                "Batata rústica", "Arroz com castanhas", "Pão com ovo", "Tofu ao curry", "Omelete caprese",
                "Pizza de legumes", "Panqueca recheada com ricota", "Arroz integral", "Macarrão de arroz", "Torta integral",
                "Estrogonofe de palmito", "Cuscuz marroquino", "Sopa de ervilha", "Couve refogada", "Frittata",
                "Nhoque de batata doce", "Panqueca de queijo", "Vegetais grelhados", "Polenta cremosa", "Bolinho de arroz",
                "Arroz com espinafre", "Esfiha de queijo", "Croquete de legumes", "Feijão com abóbora", "Ceviche de banana-da-terra",
                "Wrap de legumes", "Purê de batata", "Pão com requeijão", "Bife de soja", "Mingau de aveia"
        ));

        cardapio.get("intolerante").put("comida", List.of(
                "Arroz integral", "Frango grelhado", "Tofu refogado", "Sopa sem glúten", "Tapioca simples",
                "Purê de mandioca", "Carne grelhada", "Salada verde", "Panqueca sem glúten", "Ovo mexido",
                "Escondidinho de frango", "Estrogonofe sem lactose", "Macarrão sem glúten", "Arroz 7 grãos", "Panqueca de arroz",
                "Torta de frango sem glúten", "Panqueca de aveia", "Arroz branco", "Batata cozida", "Tapioca com frango",
                "Sopa de abóbora", "Legumes no vapor", "Carne com batata", "Feijão simples", "Frango desfiado",
                "Torta de arroz", "Risoto leve", "Carne moída sem molho", "Cuscuz simples", "Peito de frango grelhado",
                "Hambúrguer sem glúten", "Tapioca salgada", "Wrap de arroz", "Salada de folhas", "Estrogonofe leve",
                "Berinjela assada", "Panqueca de batata", "Frango xadrez", "Arroz com milho", "Ovo cozido",
                "Carne cozida", "Sopa de legumes sem leite", "Mingau de arroz", "Feijão carioca", "Arroz com cenoura",
                "Chuchu refogado", "Tofu grelhado", "Panqueca sem lactose", "Polenta", "Bolinho de arroz",
                "Suflê de legumes sem queijo", "Berinjela grelhada", "Wrap de legumes", "Frango ao curry leve", "Torta salgada sem glúten",
                "Cuscuz com frango", "Batata assada", "Purê de batata doce", "Feijão preto simples", "Omelete simples"
        ));

        // Bebidas
        cardapio.get("normal").put("bebida", List.of(
                "Café com leite", "Suco de laranja", "Achocolatado", "Leite puro", "Chá mate",
                "Refrigerante", "Suco verde", "Suco de uva", "Chocolate quente", "Capuccino",
                "Chá com limão", "Vitamina de banana", "Leite de soja", "Leite de aveia", "Chá preto",
                "Smoothie de frutas", "Suco de morango", "Suco de melancia", "Leite com cacau", "Café expresso",
                "Suco de abacaxi", "Suco de maçã", "Suco de maracujá", "Suco de acerola", "Milkshake leve",
                "Bebida energética", "Iogurte líquido", "Iogurte com frutas", "Suco de goiaba", "Leite fermentado",
                "Água de coco", "Chá verde", "Chá de camomila", "Chá de hibisco", "Suco multivitamínico",
                "Água mineral", "Água saborizada", "Café gelado", "Chá gelado"
        ));

        cardapio.get("vegetariano").put("bebida", List.of(
                "Suco verde", "Chá de hibisco", "Água de coco", "Chá mate", "Chá gelado",
                "Leite de aveia", "Suco de manga", "Smoothie de frutas", "Chá de camomila", "Suco detox",
                "Bebida de arroz", "Leite vegetal", "Suco de maçã", "Chá de frutas vermelhas", "Suco de abacaxi",
                "Chá de gengibre", "Capuccino vegetal", "Iogurte vegetal", "Leite de amêndoas", "Chá de hortelã",
                "Água saborizada", "Chá preto", "Suco multivitamínico", "Chá calmante", "Suco cítrico",
                "Vitamina de banana com aveia", "Suco de beterraba", "Chá branco", "Chá digestivo", "Leite de coco",
                "Chá morno", "Suco integral", "Suco de goiaba", "Água mineral", "Suco de melancia",
                "Chá com limão", "Suco de acerola", "Suco de laranja", "Chá verde"
        ));

        cardapio.get("intolerante").put("bebida", List.of(
                "Chá de ervas", "Água mineral", "Chá mate", "Chá de camomila", "Chá de hibisco",
                "Suco natural", "Suco de maçã", "Leite de arroz", "Chá digestivo", "Água de coco",
                "Suco de uva", "Chá verde", "Smoothie sem lactose", "Suco de abacaxi", "Vitamina sem leite",
                "Chá de gengibre", "Suco de acerola", "Chá calmante", "Leite de soja", "Leite de aveia",
                "Chá preto", "Suco detox", "Chá branco", "Bebida vegetal mista", "Água com gás",
                "Bebida de castanhas", "Leite de coco", "Suco de morango", "Chá de hortelã", "Chá de frutas vermelhas",
                "Chá de melissa", "Água saborizada", "Suco multivitamínico", "Chá morno", "Chá com limão",
                "Leite vegetal", "Suco de goiaba", "Chá de menta", "Bebida proteica"
        ));

// Complementos
        cardapio.get("normal").put("complemento", List.of(
                "Batata frita", "Farofa", "Salada verde", "Vinagrete", "Pão francês",
                "Queijo ralado", "Cenoura ralada", "Ovo cozido", "Pão de alho", "Torradas",
                "Salada de repolho", "Purê de batata", "Couve refogada", "Torrada com requeijão", "Salada de alface",
                "Abobrinha refogada", "Salada de tomate", "Maionese", "Pão de queijo", "Berinjela grelhada",
                "Molho branco", "Molho rosé", "Molho barbecue", "Cream cheese", "Salada tropical",
                "Torrada simples", "Cebola caramelizada", "Chips de batata", "Legumes grelhados", "Mix de folhas",
                "Molho mostarda e mel", "Molho vinagrete"
        ));

        cardapio.get("vegetariano").put("complemento", List.of(
                "Salada verde", "Torradas integrais", "Patê de grão-de-bico", "Tofu grelhado", "Cenoura ralada",
                "Legumes refogados", "Purê de batata", "Vinagrete", "Berinjela assada", "Pão integral",
                "Mix de folhas", "Molho tahine", "Chips de batata doce", "Farofa de soja", "Abobrinha grelhada",
                "Salada de repolho roxo", "Batata doce assada", "Pão sírio", "Azeitonas", "Salada de grãos",
                "Salada de tomate", "Molho de iogurte vegetal", "Cebola caramelizada", "Legumes ao vapor", "Couve refogada",
                "Salada de lentilha", "Salada de pepino", "Homus", "Tabule", "Patê de tofu",
                "Molho balsâmico", "Torrada com azeite"
        ));

        cardapio.get("intolerante").put("complemento", List.of(
                "Batata doce", "Legumes cozidos", "Salada de alface", "Pão sem glúten", "Cenoura ralada",
                "Abobrinha refogada", "Purê de batata doce", "Torrada sem glúten", "Vinagrete", "Salada de pepino",
                "Molho sem lactose", "Salada de grãos", "Couve refogada", "Berinjela grelhada", "Tofu grelhado",
                "Farofa sem glúten", "Pão de arroz", "Mix de folhas", "Chips de batata doce", "Molho de iogurte vegetal",
                "Salada de repolho", "Purê de mandioquinha", "Molho de abacate", "Molho de limão", "Torrada de arroz",
                "Salada de rúcula", "Torrada sem lactose", "Molho de ervas", "Ovo cozido", "Castanhas",
                "Molho leve", "Cebola grelhada"
        ));

// Sobremesas
        cardapio.get("normal").put("sobremesa", List.of(
                "Pudim", "Gelatina", "Bolo de cenoura", "Fruta picada", "Mousse de maracujá",
                "Torta de maçã", "Doce de leite", "Brigadeiro", "Sorvete", "Doce de abóbora",
                "Doce de banana", "Mousse de limão", "Bolo de chocolate", "Mousse de chocolate", "Torta de morango",
                "Doce de coco", "Compota de frutas", "Bolo de fubá", "Arroz doce", "Cocada"
        ));

        cardapio.get("vegetariano").put("sobremesa", List.of(
                "Fruta picada", "Banana", "Maçã", "Uva", "Manga",
                "Melancia", "Melão", "Doce de abóbora", "Pudim de chia", "Mousse de maracujá",
                "Torta de maçã", "Doce de banana", "Cocada", "Torta de limão vegana", "Bolo de banana",
                "Mousse de manga", "Torta integral de frutas", "Sorvete vegano", "Compota de maçã", "Mingau de aveia"
        ));

        cardapio.get("intolerante").put("sobremesa", List.of(
                "Fruta picada", "Banana", "Maçã", "Uva", "Melancia",
                "Melão", "Mousse sem lactose", "Doce de abóbora", "Gelatina", "Torta sem glúten",
                "Doce de banana", "Mousse de maracujá", "Cocada", "Doce de coco", "Torta de maçã",
                "Compota de pêssego", "Sorvete sem lactose", "Arroz doce com leite vegetal", "Bolo sem glúten", "Mousse de manga"
        ));
        for (String type : types) {
            for (String subtype : subtypes) {
                Map<String, List<String>> grupo = cardapio.get(subtype);
                for (int i = 0; i < itemTypes.length; i++) {
                    String itemType = itemTypes[i];
                    List<String> options = new ArrayList<>(grupo.get(itemType));
                    Collections.shuffle(options);
                    for (int j = 0; j < limits[i]; j++) {
                        String name = options.get(j % options.size());
                        String description = name + " para " + subtype;
                        double price = 1.5 + rand.nextInt(400) / 100.0;
                        double rating = 3.0 + rand.nextDouble() * 2.0;
                        addMeal(date, type, subtype, itemType, name, description, price, rating);
                    }
                }
            }
        }
    }

    public void addComment(int mealId, String username, String newComment) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("meal_id", mealId);
        values.put("username", username);
        values.put("comment", newComment);
        db.insert("comments", null, values);
    }

    public List<Comment> getCommentsForMeal(int mealId) {
        List<Comment> comments = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM comments WHERE meal_id = ?", new String[]{String.valueOf(mealId)});

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
                String text = cursor.getString(cursor.getColumnIndexOrThrow("comment"));
                comments.add(new Comment(username, text));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return comments;
    }
}
