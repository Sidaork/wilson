package com.example.tanamao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tanamao.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_MEALS = "meals";
    private static final String TABLE_COMMENTS = "comments";
    private static final String TABLE_PURCHASES = "purchases";

    private final Random random = new Random();

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (username TEXT PRIMARY KEY, password TEXT, saldo REAL, total_gasto REAL, total_recarga REAL)");
        db.execSQL("CREATE TABLE " + TABLE_MEALS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, type TEXT, name TEXT, description TEXT, price REAL, rating REAL, image_name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_COMMENTS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, meal_id INTEGER, username TEXT, comment TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_PURCHASES + " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, meal_id INTEGER)");
        populateFirstWeekMenus(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PURCHASES);
        onCreate(db);
    }

    private void populateFirstWeekMenus(SQLiteDatabase db) {
        String[] weekdays = {"03/06/2025", "04/06/2025", "05/06/2025", "06/06/2025", "07/06/2025", "08/06/2025", "09/06/2025"};
        for (String date : weekdays) {
            generateMenuForDate(db, date);
        }
    }

    public void generateMenuForDate(SQLiteDatabase db, String date) {
        if (isWithinSevenDays(date)) {
            db.delete(TABLE_MEALS, "date = ?", new String[]{date});

            insertMeal(db, date, "cafe_normal", "Pão com manteiga", "Café com pão e manteiga", 4.50, 5.0, "cafe_01");
            insertMeal(db, date, "cafe_vegetariano", "Frutas e granola", "Café vegetariano leve", 5.00, 5.0, "cafe_veg");
            insertMeal(db, date, "cafe_intolerante", "Tapioca com banana", "Café para intolerantes", 5.20, 5.0, "cafe_int");

            insertMeal(db, date, "almoco_normal", "Feijoada", "Almoço tradicional com arroz, feijão e carne", 10.00, 5.0, "almoco_01");
            insertMeal(db, date, "almoco_vegetariano", "Lasanha de berinjela", "Lasanha sem carne com queijo e tomate", 9.50, 5.0, "almoco_veg");
            insertMeal(db, date, "almoco_intolerante", "Frango grelhado e legumes", "Refeição leve e sem glúten", 9.00, 5.0, "almoco_int");

            insertMeal(db, date, "jantar_normal", "Macarronada", "Macarrão ao sugo com carne moída", 8.00, 5.0, "jantar_01");
            insertMeal(db, date, "jantar_vegetariano", "Risoto de legumes", "Jantar vegetariano nutritivo", 7.50, 5.0, "jantar_veg");
            insertMeal(db, date, "jantar_intolerante", "Sopa de mandioca", "Jantar sem lactose e sem glúten", 7.20, 5.0, "jantar_int");
        }
    }

    private void insertMeal(SQLiteDatabase db, String date, String type, String name, String description, double price, double rating, String imageName) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("type", type);
        values.put("name", name);
        values.put("description", description);
        values.put("price", price);
        values.put("rating", rating);
        values.put("image_name", imageName);
        db.insert(TABLE_MEALS, null, values);
    }

    private boolean isWithinSevenDays(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {
            Date mealDate = sdf.parse(date);
            Date today = new Date();
            long diff = mealDate.getTime() - today.getTime();
            long days = diff / (1000 * 60 * 60 * 24);
            return days >= 0 && days <= 7;
        } catch (ParseException e) {
            return false;
        }
    }

    public List<Meal> getMealsForDate(String date) {
        List<Meal> meals = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_MEALS, null, "date = ?", new String[]{date}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                meals.add(new Meal(
                        cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("date")),
                        cursor.getString(cursor.getColumnIndexOrThrow("type")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("description")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("rating")),
                        cursor.getString(cursor.getColumnIndexOrThrow("image_name"))
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return meals;
    }

    public Meal getMealById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_MEALS, null, "id = ?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Meal meal = new Meal(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    cursor.getString(cursor.getColumnIndexOrThrow("type")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                    cursor.getDouble(cursor.getColumnIndexOrThrow("rating")),
                    cursor.getString(cursor.getColumnIndexOrThrow("image_name"))
            );
            cursor.close();
            return meal;
        }
        return null;
    }

    public void addComment(int mealId, String username, String comment) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("meal_id", mealId);
        values.put("username", username);
        values.put("comment", comment);
        db.insert(TABLE_COMMENTS, null, values);
    }

    public List<Comment> getCommentsForMeal(int mealId) {
        List<Comment> comments = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_COMMENTS, null, "meal_id = ?", new String[]{String.valueOf(mealId)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                comments.add(new Comment(
                        cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("meal_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("username")),
                        cursor.getString(cursor.getColumnIndexOrThrow("comment"))
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return comments;
    }

    public void updateMealRating(int mealId, float rating) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rating", rating);
        db.update(TABLE_MEALS, values, "id = ?", new String[]{String.valueOf(mealId)});
    }

    public void addToCart(String username, int mealId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("meal_id", mealId);
        db.insert(TABLE_PURCHASES, null, values);
    }

    public double getSaldoUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{"saldo"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double saldo = cursor.getDouble(cursor.getColumnIndexOrThrow("saldo"));
            cursor.close();
            return saldo;
        }
        return 0.0;
    }

    public double getTotalGastoUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{"total_gasto"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double total = cursor.getDouble(cursor.getColumnIndexOrThrow("total_gasto"));
            cursor.close();
            return total;
        }
        return 0.0;
    }

    public double getTotalRecargaUsuario(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{"total_recarga"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double total = cursor.getDouble(cursor.getColumnIndexOrThrow("total_recarga"));
            cursor.close();
            return total;
        }
        return 0.0;
    }

    public boolean atualizarSenha(String username, String novaSenha) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password", novaSenha);
        int rowsAffected = db.update(TABLE_USERS, values, "username = ?", new String[]{username});
        return rowsAffected > 0;
    }

    public void atualizarSaldo(String username, double novoSaldo) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("saldo", novoSaldo);
        db.update(TABLE_USERS, values, "username = ?", new String[]{username});
    }

    public void atualizarTotalRecarga(String username, double valor) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{"total_recarga"}, "username = ?", new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            double atual = cursor.getDouble(cursor.getColumnIndexOrThrow("total_recarga"));
            cursor.close();

            ContentValues values = new ContentValues();
            values.put("total_recarga", atual + valor);
            db.update(TABLE_USERS, values, "username = ?", new String[]{username});
        }
    }
}
