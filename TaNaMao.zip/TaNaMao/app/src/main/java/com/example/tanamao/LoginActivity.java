package com.example.tanamao;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, birthDateEditText, passwordEditText;
    private Button loginButton, registerButton, forgotPasswordButton;
    private CheckBox rememberLoginCheckBox;

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "UserPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.username);
        birthDateEditText = findViewById(R.id.birth_date);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);
        forgotPasswordButton = findViewById(R.id.forgot_password_button);
        rememberLoginCheckBox = findViewById(R.id.remember_login);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Carregar login salvo se existir
        boolean remember = sharedPreferences.getBoolean("remember_login", false);
        if (remember) {
            String savedUser = sharedPreferences.getString("saved_username", "");
            usernameEditText.setText(savedUser);
            rememberLoginCheckBox.setChecked(true);
        }

        // Navegação de campos via teclado
        usernameEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                birthDateEditText.requestFocus();
                return true;
            }
            return false;
        });

        birthDateEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                passwordEditText.requestFocus();
                return true;
            }
            return false;
        });

        passwordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                loginButton.performClick();
                return true;
            }
            return false;
        });

        // Máscara da data
        birthDateEditText.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private final String ddmmyyyy = "DDMMYYYY";
            private final Calendar cal = Calendar.getInstance();

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(current)) {
                    String clean = s.toString().replaceAll("[^\\d]", "");
                    String cleanC = current.replaceAll("[^\\d]", "");

                    int cl = clean.length();
                    int sel = cl;
                    for (int i = 2; i <= cl && i < 6; i += 2) sel++;
                    if (clean.equals(cleanC)) sel--;

                    if (clean.length() < 8) {
                        clean = clean + ddmmyyyy.substring(clean.length());
                    } else {
                        int day = Integer.parseInt(clean.substring(0, 2));
                        int mon = Integer.parseInt(clean.substring(2, 4));
                        int year = Integer.parseInt(clean.substring(4, 8));

                        mon = Math.max(1, Math.min(mon, 12));
                        cal.set(Calendar.MONTH, mon - 1);
                        year = Math.max(1900, Math.min(year, 2100));
                        cal.set(Calendar.YEAR, year);

                        day = Math.min(day, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                        clean = String.format("%02d%02d%04d", day, mon, year);
                    }

                    clean = String.format("%s/%s/%s",
                            clean.substring(0, 2),
                            clean.substring(2, 4),
                            clean.substring(4, 8));

                    sel = Math.max(0, sel);
                    current = clean;
                    birthDateEditText.setText(current);
                    birthDateEditText.setSelection(sel < current.length() ? sel : current.length());
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        // Login
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            String storedPassword = sharedPreferences.getString(username + "_password", null);
            if (storedPassword == null) {
                Toast.makeText(LoginActivity.this, "Usuário não existe, crie uma conta", Toast.LENGTH_SHORT).show();
            } else if (!storedPassword.equals(password)) {
                Toast.makeText(LoginActivity.this, "Senha errada, redefina", Toast.LENGTH_SHORT).show();
            } else {
                // Salvar login se checkbox marcado
                SharedPreferences.Editor editor = sharedPreferences.edit();
                if (rememberLoginCheckBox.isChecked()) {
                    editor.putBoolean("remember_login", true);
                    editor.putString("saved_username", username);
                } else {
                    editor.remove("remember_login");
                    editor.remove("saved_username");
                }
                editor.apply();

                Toast.makeText(LoginActivity.this, "Login bem-sucedido", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            }
        });

        // Cadastro
        registerButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String birthDate = birthDateEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || birthDate.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (username.length() < 4 || username.length() > 16) {
                Toast.makeText(LoginActivity.this, "Usuário deve ter entre 4 e 16 caracteres", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!birthDate.matches("\\d{2}/\\d{2}/\\d{4}")) {
                Toast.makeText(LoginActivity.this, "Data de nascimento inválida", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.matches("\\d{4,8}")) {
                Toast.makeText(LoginActivity.this, "Senha deve conter de 4 a 8 dígitos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (sharedPreferences.contains(username + "_password")) {
                Toast.makeText(LoginActivity.this, "Usuário já existe", Toast.LENGTH_SHORT).show();
            } else {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(username + "_password", password);
                editor.putString(username + "_birth_date", birthDate);
                editor.apply();
                Toast.makeText(LoginActivity.this, "Usuário registrado com sucesso", Toast.LENGTH_SHORT).show();
            }
        });

        // Redefinir senha
        forgotPasswordButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String birthDate = birthDateEditText.getText().toString().trim();

            if (username.isEmpty() || birthDate.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Preencha usuário e data de nascimento", Toast.LENGTH_SHORT).show();
                return;
            }

            String storedBirthDate = sharedPreferences.getString(username + "_birth_date", null);
            if (storedBirthDate == null || !storedBirthDate.equals(birthDate)) {
                Toast.makeText(LoginActivity.this, "Dados inválidos", Toast.LENGTH_SHORT).show();
            } else {
                String newPassword = String.valueOf((int) (Math.random() * 9000) + 1000);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(username + "_password", newPassword);
                editor.apply();
                Toast.makeText(LoginActivity.this, "Nova senha: " + newPassword, Toast.LENGTH_LONG).show();
            }
        });
    }
}
